/****************************************************************************
 * Copyright (c) 2023 PX4 Development Team.
 * SPDX-License-Identifier: BSD-3-Clause
 ****************************************************************************/
#pragma once

#include <px4_ros2/components/mode.hpp>
#include <px4_ros2/components/mode_executor.hpp>
#include <px4_ros2/components/wait_for_fmu.hpp>
//#include <px4_ros2/control/setpoint_types/experimental/trajectory.hpp>

#include <rclcpp/rclcpp.hpp>

#include <Eigen/Core>


//Gps point stuff
#include <px4_ros2/control/setpoint_types/goto.hpp>
#include <px4_ros2/odometry/attitude.hpp>
#include <px4_ros2/odometry/global_position.hpp>
#include <px4_ros2/utils/geometry.hpp>
#include <px4_ros2/utils/geodesic.hpp>
#include "std_msgs/msg/string.hpp"
#include <algorithm>

//search pattern stuff
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <vector>

//#include <std_msgs/msg/int16_multi_array.h>
#define M_PI 3.14159265358979323846


using namespace std::chrono_literals; // NOLINT

static const std::string kName = "Autonomous Executor";
//----------------------------------------------------

//std_msgs::int16_multi_array wheel_ticks;
//std_msgs::msg::multi_array Int16MultiArray msg = Int16MultiArray()

//------------------------------------------
using namespace px4_ros2::literals; // NOLINT

class FlightModeTest : public px4_ros2::ModeBase
{
public:
//   explicit FlightModeTest(rclcpp::Node & node)
//   : ModeBase(node, Settings{kName, false})

  explicit FlightModeTest(rclcpp::Node & node)
  : ModeBase(node, Settings(kName, false))
  {
    _goto_setpoint = std::make_shared<px4_ros2::GotoGlobalSetpointType>(*this);

    _vehicle_global_position = std::make_shared<px4_ros2::OdometryGlobalPosition>(*this);
    _vehicle_attitude = std::make_shared<px4_ros2::OdometryAttitude>(*this);
    
    makeCoordList();
    radio_publisher_ = node.create_publisher<std_msgs::msg::String>("Ugv_Link", 10);
    // radio_publisher2_ = node.create_publisher<std_msgs::msg::String>("Ugv_Link", 10);


     auto message2 = std_msgs::msg::String();
     message2.data = "GpsFlightModeEstablished";
     radio_publisher_->publish(message2);


      //Offboard_Subscriber_ = node.create_subscriber<std_msgs::msg::String>("Angle_To_Control", 10);

      Offboard_Subscriber_ = node.create_subscription<std_msgs::msg::String>(
        "Angle_To_Control", 10, std::bind(&FlightModeTest::GPS_ARUCO_Calculate, this, std::placeholders::_1));

     //radio_publisher_->publish("Coords established");needs aruco pub modifications
       


  }

  void onActivate() override
  {
    _state = State::SettlingAtStart;
    _start_position_set = false;
    _start_heading_set = false;
  }

  void GPS_ARUCO_Calculate(const std_msgs::msg::String::SharedPtr msg){//will be subscriber from program will trigger interrupt
    std::string temp =  msg->data.c_str();
    
    std::stringstream message1(temp);

    float angle_x, angle_y;

    message1 >> angle_x >> angle_y;
    
    
    float height = mission_alt;

    float dist_x = std::tan(angle_x* 3.14159/180)* height;
    float dist_y = std::tan(angle_y*3.14159/180)* height;
    Eigen::Vector3f distance = Eigen::Vector3f(dist_x, dist_y, mission_alt);
    //Eigen::Vector3d curr = Eigen::Vector2d(_vehicle_global_position->position().x, _vehicle_global_position->position().y)
    const Eigen::Vector3d place =  px4_ros2::addVectorToGlobalPosition(_vehicle_global_position->position(), distance);

    auto message4= std_msgs::msg::String();
    message4.data = "dist_x lat" +std::to_string(place.x())+"dist_y"+std::to_string(place.y());
    radio_publisher_->publish(message4);

  }


  void onDeactivate() override {}

  void updateSetpoint(float dt_s) override
  {

    if (!_start_position_set) {
      _start_position_m = _vehicle_global_position->position();
      _start_position_set = true;
    }


    switch (_state) {
      case State::SettlingAtStart: {
          // just settling at the starting vehicle position
          _goto_setpoint->update(_start_position_m);
          if (positionReached(_start_position_m)) {
            _state = State::MissionPoints;
          }
        }
        break;


      case State::MissionPoints: {
          // should make system go to target position gps in meter conversion
          //Test Point 
        
          //Eigen::Vector3d & GPS_Point;//next lat [deg], lon [deg], alt AMSL [m]
          //for test point

           
          Eigen::Vector3d GPS_Point = Eigen::Vector3d((gps_path[pattern_iterator].first/ 60.0), (gps_path[pattern_iterator].second/ 60.0), mission_alt);
          //Eigen::Vector3d GPS_Point = Eigen::Vector3d(32.1709399, -96.0608695, 5.0);//next lat [deg], lon [deg], alt AMSL [m]

           auto message = std_msgs::msg::String();
            message.data = "Headedto lat" +std::to_string((gps_path[pattern_iterator].first/ 60.0))+"Lon"+std::to_string((gps_path[pattern_iterator].second/ 60.0))+"alt"+std::to_string(mission_alt);
            radio_publisher_->publish(message);
   
          //Eigen::Vector3f target  = px4_ros2::vectorToGlobalPosition(_vehicle_global_position->position(), GPS_Point);//target_position_m
          //px4_ros2::addVectorToGlobalPosition(_start_position_m, Eigen::Vector3f{kTriangleHeight, kTriangleWidth, 0.f});

          //static_cast<Eigen::Vector2d> to cast
          // scale the speed limits by distance to the target
          //const float distance_to_target = px4_ros2::horizontalDistanceToGlobalPosition(
          //_vehicle_global_position->position(), target_position_m);
          //Eigen::Vector3d target_position_m = static_cast<Eigen::Vector3d> target

          // const float speed_scale = 1.f;//std::min(distance_to_target / kTriangleWidth, 1.f);


          // const float max_horizontal_velocity_m_s = 5.f * speed_scale + (1.f - speed_scale) * 1.f;
          // const float max_vertical_velocity_m_s = 3.f * speed_scale + (1.f - speed_scale) * 0.5f;
          // const float max_heading_rate_rad_s =
          //   px4_ros2::degToRad(45.f * speed_scale + (1.f - speed_scale) * 25.f);
          // const float heading_setpoint_rate_of_change =
          //   px4_ros2::degToRad(40.f * speed_scale + (1.f - speed_scale) * 20.f);

          // if (!_start_heading_set) {
          //   _spinning_heading_rad = _vehicle_attitude->yaw();
          //   _start_heading_set = true;
          // }

          //makes drone spin will remove
          // if (!positionReached(target_position_m)) {
          //   _spinning_heading_rad += heading_setpoint_rate_of_change * dt_s;
          // }

         // updates point
          // _goto_setpoint->update(
          //   target_position_m,
          //   _spinning_heading_rad,
          //   max_horizontal_velocity_m_s,
          //   max_vertical_velocity_m_s,
          //   max_heading_rate_rad_s);

        // updates point

        //goto contains a gps coord version
          _goto_setpoint->update(GPS_Point);


          //override for scanning
          // if(1==1){//aruco detect

          

          // }

          if (positionReached(GPS_Point)) {
            pattern_iterator++;
            
            
            //set next point to go to answer service call
            if(pattern_iterator >= gps_path.size()){
              completed(px4_ros2::Result::Success);
            }else{
            _state = State::MissionPoints;
            }
            //return;
          }

        
        }
        break;
   
  }
  }//was missing
private:
  std::vector<std::pair<double, double>> gps_path;
  int pattern_iterator = 0;
  float mission_alt = 5.0;
  static constexpr float kTriangleHeight = 20.f; // [m]
  static constexpr float kTriangleWidth = 30.f; // [m]
  

  enum class State
  {
    SettlingAtStart = 0,
    MissionPoints
  } _state;

  // NED earth-fixed frame. box pattern starting corner (first position the mode sees on activation)
  Eigen::Vector3d _start_position_m;
  bool _start_position_set{false};

  // [-pi, pi] current heading setpoint during spinning phase
  float _spinning_heading_rad{0.f};

  // used for heading initialization when dynamically updating heading setpoints
  bool _start_heading_set{false};


  std::shared_ptr<px4_ros2::GotoGlobalSetpointType> _goto_setpoint;
  std::shared_ptr<px4_ros2::OdometryGlobalPosition> _vehicle_global_position;
  std::shared_ptr<px4_ros2::OdometryAttitude> _vehicle_attitude;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr radio_publisher_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr Offboard_Subscriber_;
  

  //perfect for application
  
  bool positionReached(const Eigen::Vector3d & target_position_m) const
  {
    static constexpr float kPositionErrorThreshold = 0.5f; // [m]
    const float position_error = px4_ros2::distanceToGlobalPosition(
      _vehicle_global_position->position(), target_position_m);
    return position_error < kPositionErrorThreshold;
  }
  
  
  // bool positionReached(const Eigen::Vector3d & target_position_m) const
  // {
  //   static constexpr float kPositionErrorThreshold = 0.5f; // [m]
  //   const float position_error = px4_ros2::distanceToGlobalPosition(
  //     _vehicle_global_position->position(), target_position_m);
  //   return position_error < kPositionErrorThreshold;
  // }


//if we want to do pattern as well
  bool headingReached(float target_heading_rad) const
  {
    static constexpr float kHeadingErrorThreshold = 7.0_deg;
    const float heading_error_wrapped = px4_ros2::wrapPi(
      target_heading_rad - _vehicle_attitude->yaw());
    return fabsf(heading_error_wrapped) < kHeadingErrorThreshold;
  }






//Search Algorithm

  double convertMin(double x) {
    double deg = int(x) * 60.0;
    double md = (x-int(x)) * 60.0;
    double tot = deg + md;
    //cout << fixed << setprecision(12) << "tot: " << tot << endl;
   
    return tot;
}
double dist(std::pair<double, double> corr1, std::pair<double, double> corr2) {
    double nautFt = 6076.11549;
    double deltaPhi = pow((corr1.first-corr2.first), 2.0);
    double deltaLamb = (corr1.second-corr2.second);
    double avgLongDeg = (corr1.first/60.0+corr2.first/60.0) / 2.0;
    double distance = sqrt(deltaPhi + pow(cos(avgLongDeg * M_PI / 180) * deltaLamb, 2));
    return distance * nautFt;
}

std::vector<std::pair<double, double>> fieldCorrdinates(std::pair<double, double> topLeft, std::pair<double, double> bottomLeft, std::pair<double, double> bottomRight, double cameraArea) {
    std::vector<std::pair<double,double>> gpsCorrds; 
    double width = dist(bottomLeft, bottomRight);
    double length = dist(topLeft, bottomLeft);
    double widthPortions = width / sqrt(cameraArea);
    double lengthPortions = length / sqrt(cameraArea);
    //cout << width << " " << length << endl;

    int nodeNumL = ceil(lengthPortions);
    int nodeNumW = ceil(widthPortions);
    int end = 1;
    double lengthStep = length / nodeNumL;
    double widthStep = width / nodeNumW;
    //cout << "NodeNum: " << nodeNumL << " " << nodeNumW << endl;
    //cout << "Step: " << lengthStep << " " << widthStep << endl;
    std::pair<double, double> moveRight((widthStep/width) * (bottomRight.first-bottomLeft.first), (widthStep/width) * (bottomRight.second-bottomLeft.second));
    std::pair<double, double> moveUp((lengthStep/length) * (topLeft.first- bottomLeft.first), (lengthStep/length) * (topLeft.second - bottomLeft.second));
    std::pair<double, double> newCorr(bottomLeft.first + moveUp.first, bottomLeft.second + moveUp.second);
    gpsCorrds.push_back(newCorr);
    for (int i = 0; i < nodeNumW; ++i) {
        int l = gpsCorrds.size() - 1;
        std::pair<double, double> newChorrds((gpsCorrds[l].first + moveRight.first), gpsCorrds[l].second + moveRight.second);
        gpsCorrds.push_back(newChorrds);
        for(int j = 0; j < nodeNumL - 1; ++j){
            int l = gpsCorrds.size() - 1;
            if (end == 1) {
            newChorrds.first = newChorrds.first + moveUp.first;
            newChorrds.second = newChorrds.second + moveUp.second;
            gpsCorrds.push_back(newChorrds);
            } else if (end == -1) {
            newChorrds.first = newChorrds.first + moveUp.first * -1;
            newChorrds.second = newChorrds.second + moveUp.second * -1;
            gpsCorrds.push_back(newChorrds);
            }
        }
        end *= -1;
    }


    return gpsCorrds;
    
}


//used to be nicolas main
void makeCoordList() {
  //geofence coords
    std::pair<double, double> coor1(convertMin(32.1734675), convertMin(-96.0581169)); 
    std::pair<double, double> coor2(convertMin(32.1734050), convertMin(-96.0580953)); 
    std::pair<double, double> coor3(convertMin(32.1734225), convertMin(-96.0580255)); 
    
    double distance = dist(coor1, coor2);
    //cout<< coor1.first << endl;
    //cout << distance << "ft" << endl;
     gps_path = fieldCorrdinates(coor1, coor2, coor3, 625);//last is camera fov
    // for (int i = 0; i < gps_path.size(); ++i) {

    //     std::cout << gps_path[i].first / 60.0 << "," << gps_path[i].second /60.0 << std::endl;

    // } 

    
}



};















//the old custom mode test
//----------------------------------------------------
// class FlightModeTest : public px4_ros2::ModeBase
// {
// public:
//   explicit FlightModeTest(rclcpp::Node & node)
//   : ModeBase(node, Settings{kName, false})
//   {
//     _trajectory_setpoint = std::make_shared<px4_ros2::TrajectorySetpointType>(*this);
//   }

//   ~FlightModeTest() override = default;

//   void onActivate() override
//   {
//     _activation_time = node().get_clock()->now();
//   }

//   void onDeactivate() override {}

//   void updateSetpoint(float dt_s) override
//   {
//     const rclcpp::Time now = node().get_clock()->now();

//     if (now - _activation_time > 5s) {
//       completed(px4_ros2::Result::Success);
//       return;
//     }

//     const float elapsed_s = (now - _activation_time).seconds();
//     const Eigen::Vector3f velocity{10.f, elapsed_s * 2.f, -2.f};
//     _trajectory_setpoint->update(velocity);
//   }

// private:
//   rclcpp::Time _activation_time{};
//   std::shared_ptr<px4_ros2::TrajectorySetpointType> _trajectory_setpoint;
// };






//The main program executor
class ModeExecutorTest : public px4_ros2::ModeExecutorBase
{
public:
  ModeExecutorTest(rclcpp::Node & node, px4_ros2::ModeBase & owned_mode)
  : ModeExecutorBase(node, px4_ros2::ModeExecutorBase::Settings{}, owned_mode),
    _node(node)
  {

    radio_publisher2_ = node.create_publisher<std_msgs::msg::String>("Ugv_Link", 10);
    auto message = std_msgs::msg::String();
    message.data = "FlightModeEstablished";
    radio_publisher2_->publish(message);

  }

  enum class State
  {
    Reset,
    TakingOff,
    MyMode,
    RTL,
    WaitUntilDisarmed,
  };

  void onActivate() override
  {
    runState(State::TakingOff, px4_ros2::Result::Success);
  }

  void onDeactivate(DeactivateReason reason) override
  {
  }

  void runState(State state, px4_ros2::Result previous_result)
  {
    if (previous_result != px4_ros2::Result::Success) {
      RCLCPP_ERROR(
        _node.get_logger(), "State %i: previous state failed: %s", (int)state,
        resultToString(previous_result));
      return;
    }

    RCLCPP_DEBUG(_node.get_logger(), "Executing state %i", (int)state);

    switch (state) {
      case State::Reset:
        break;

      case State::TakingOff:
        takeoff([this](px4_ros2::Result result) {runState(State::MyMode, result);});
        break;

      case State::MyMode:
        scheduleMode(
          ownedMode().id(), [this](px4_ros2::Result result) {
            runState(State::RTL, result);
          });
        break;

      case State::RTL:
        rtl([this](px4_ros2::Result result) {runState(State::WaitUntilDisarmed, result);});
        break;

      case State::WaitUntilDisarmed:
        waitUntilDisarmed(
          [this](px4_ros2::Result result) {
            RCLCPP_INFO(_node.get_logger(), "All states complete (%s)", resultToString(result));
          });
        break;
    }
  }

private:
  rclcpp::Node & _node;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr radio_publisher2_;
};
