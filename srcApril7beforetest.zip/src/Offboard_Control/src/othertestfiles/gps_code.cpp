// Online C++ compiler to run C++ program online
#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#define M_PI 3.14159265358979323846
using namespace std;

float convertMin(float x) {
    float deg = int(x) * 60.0;
    float md = (x-int(x)) * 60.0;
    float tot = deg + md;
    cout << fixed << setprecision(12) << "tot: " << tot << endl;
    return tot;
}
float dist(pair<float, float> corr1, pair<float, float> corr2) {
    float nautFt = 6076.11549;
    float deltaPhi = pow((corr1.first-corr2.first), 2.0);
    float deltaLamb = (corr1.second-corr2.second);
    float avgLongDeg = (corr1.first/60.0+corr2.first/60.0) / 2.0;
    float distance = sqrt(deltaPhi + pow(cos(avgLongDeg * M_PI / 180) * deltaLamb, 2));
    return distance * nautFt;
}

vector<pair<float, float>> fieldCorrdinates(pair<float, float> topLeft, pair<float, float> bottomLeft, pair<float, float> bottomRight, float cameraArea) {
    vector<pair<float,float>> gpsCorrds; 
    float width = dist(bottomLeft, bottomRight);
    float length = dist(topLeft, bottomLeft);
    float widthPortions = width / sqrt(cameraArea);
    float lengthPortions = length / sqrt(cameraArea);
    cout << width << " " << length << endl;

    int nodeNumL = ceil(lengthPortions);
    int nodeNumW = ceil(widthPortions);
    int end = 1;
    float lengthStep = length / nodeNumL;
    float widthStep = width / nodeNumW;
    cout << "NodeNum: " << nodeNumL << " " << nodeNumW << endl;
    cout << "Step: " << lengthStep << " " << widthStep << endl;
    pair<float, float> moveRight((widthStep/width) * (bottomRight.first-bottomLeft.first), (widthStep/width) * (bottomRight.second-bottomLeft.second));
    pair<float, float> moveUp((lengthStep/length) * (topLeft.first- bottomLeft.first), (lengthStep/length) * (topLeft.second - bottomLeft.second));
    pair<float, float> newCorr(bottomLeft.first + moveUp.first, bottomLeft.second + moveUp.second);
    gpsCorrds.push_back(newCorr);
    for (int i = 0; i < nodeNumW; ++i) {
        int l = gpsCorrds.size() - 1;
        pair<float, float> newChorrds((gpsCorrds[l].first + moveRight.first), gpsCorrds[l].second + moveRight.second);
        gpsCorrds.push_back(newChorrds);
        for(int j = 0; j < nodeNumL - 1; ++j){
            int l = gpsCorrds.size() - 1;
            if (end == 1) {
            newChorrds.first = newChorrds.first + moveUp.first;
            newChorrds.second = newChorrds.second + moveUp.second;
            gpsCorrds.push_back(newChorrds);
            } else if (end == -1) {
            newChorrds.first = newChorrds.first + moveUp.first * -1;
            newChorrds.second = newChorrds.second + moveUp.second * -1;
            gpsCorrds.push_back(newChorrds);
            }
        }
        end *= -1;
    }


    return gpsCorrds;
    
}



int main() {
    pair<float, float> coor1(convertMin(32.84174748179518), convertMin(-96.76342829966643)); 
    pair<float, float> coor2(convertMin(32.84153714247784), convertMin(-96.76334503754308)); 
    pair<float, float> coor3(convertMin(32.841622023229235), convertMin(-96.76300987933573)); 
    
    float distance = dist(coor1, coor2);
    cout<< coor1.first << endl;
    cout << distance << "ft" << endl;
    vector<pair<float, float>> path = fieldCorrdinates(coor1, coor2, coor3, 625);
    for (int i = 0; i < path.size(); ++i) {
        cout << path[i].first / 60.0 << "," << path[i].second /60.0 << endl;
    } 

    return 0;
}