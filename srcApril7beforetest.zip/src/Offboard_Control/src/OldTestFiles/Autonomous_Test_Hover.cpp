#include "Autonomous_Test_Hover.hpp"
#include "rclcpp/rclcpp.hpp"

//Initializes global navigation correction test


int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ExampleGlobalNavigationNode>());
  rclcpp::shutdown();
  return 0;
}
