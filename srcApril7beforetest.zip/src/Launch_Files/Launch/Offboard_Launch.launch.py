
__author__ = "Braden Wagstaff"
__contact__ = "braden@arkelectron.com"

from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    #package_dir = get_package_share_directory('px4_offboard')
    
#TODO add process node to run command line stuff like start dds client and connect px4

    #When adding nodes must exec_depend package in the launch package xml

    #------------------------
    

    #------------------------
    #prefix=gnome-terminal --' opens a new terminal for that node
    #name allows custom names at runtime of nodes
    #also can declare each node parameters using parameters=[{param1: 4}, {param2: 5}]

# Node(
#             package='Aruco_Detect',
#             #namespace='px4_offboard',
#             executable='Aruco_Detection2Sub',
#             #name='visualizer'
#         ),


    return LaunchDescription([
       Node(
            package='Aruco_Detect',
            #namespace='px4_offboard',
            executable='Aruco_Detection1Pub',
            #name='visualizer'
            prefix='gnome-terminal --'
        ),
        Node(
            package='Aruco_Detect',
            #namespace='px4_offboard',
            executable='Aruco_Detection2Sub',
            #name='visualizer'
            prefix='gnome-terminal --'
        ),
        Node(
            package='gimbal_driver',
            #namespace='px4_offboard',
            executable='GimbalNode',
            #name='processes',
            #prefix='gnome-terminal --'
        ),
        Node(
            package='Offboard_Control',
            #namespace='px4_offboard',
            executable='AutonomousNode',
            name='Offboard_Control',
            #prefix='gnome-terminal --',
        ),
        
        Node(
            package='sender',
            #namespace='px4_offboard',
            executable='UgvLinkNode',
            #name='velocity'
        ),
        Node(
            package='cmd_process',
            #namespace='px4_offboard',
            executable='cmdNode',
            #name='velocity'
        )
        
    ])
# Node(
#             package='Search_Protocol',
#             #namespace='px4_offboard',
#             executable='SearchNode',
#             #name='velocity'
#         ),