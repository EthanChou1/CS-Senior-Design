image_geometry
==============

image_geometry simplifies interpreting images geometrically using the
parameters from sensor_msgs/CameraInfo.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Python API Docs <python_api>
   C++ API Docs <generated/index>