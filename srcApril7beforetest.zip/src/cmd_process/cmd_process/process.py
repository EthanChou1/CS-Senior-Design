
#!/usr/bin/env python3

# Import the subprocess and time modules
import subprocess
import time
import serial.tools.list_ports as ser2

def main(args=None):
    #finds corrce object to connect through ports
    ports = ser2.grep("0403:6001")# Silicon Labs CP210x UART Bridge
    device = "none"

    for p in ports:
        device = p[0]

    Drone_port_opening = "sudo MicroXRCEAgent serial --dev "+ device + " -b 921600"
    
#RCLCPP_INFO(this->get_logger(), "The correct ArUco code",id, distance, angle_x, angle_y);




    #self.declare_parameter('port', device)
# List of commands to run
    commands = [
    # Run the Micro XRCE-DDS Agent simulation
    #"MicroXRCEAgent udp4 -p 8888",
    #"sudo MicroXRCEAgent serial --dev /dev/ttyUSB0 -b 921600"

    #"sudo MicroXRCEAgent serial --dev /dev/ttyUSB0 -b 921600"

    Drone_port_opening
    
    # Run the PX4 SITL simulation empty world
    #"cd ~/PX4-Autopilot && make px4_sitl gz_x500_gimbal"

    #runs custom world in the px4 simulation gz worlds folder then uses the x500_ gimbal drone
    #"cd ~/PX4-Autopilot && PX4_GZ_WORLD=aruco make px4_sitl gz_x500_gimbal"

    # Run QGroundControl
    # "cd ~/QGroundControl && ./QGroundControl.AppImage"

    #add a auto enable for qground control
    #"./QGroundControl.AppImage"
]

# Loop through each command in the list
    for command in commands:
    # Each command is run in a new tab of the gnome-terminal
        subprocess.run(["gnome-terminal", "--tab", "--", "bash", "-c", command + "; exec bash"])
    
    # Pause between each command
        time.sleep(1)
